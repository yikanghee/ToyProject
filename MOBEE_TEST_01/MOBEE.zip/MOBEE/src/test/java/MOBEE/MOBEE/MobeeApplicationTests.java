package MOBEE.MOBEE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
